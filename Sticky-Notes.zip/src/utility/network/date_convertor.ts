const dateConvertor = (userDate: string): any => {
  const today: any = new Date();
  const endDate: any = new Date(userDate);
};

export default dateConvertor;
